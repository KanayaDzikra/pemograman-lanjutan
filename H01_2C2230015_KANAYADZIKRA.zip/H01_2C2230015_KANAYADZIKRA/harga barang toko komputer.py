# Input harga dasar dan harga jual untuk setiap barang
harga_dasar_a = int(input("Masukkan harga dasar barang A: "))
harga_jual_a = int(input("Masukkan harga jual barang A: "))
harga_dasar_b = int(input("Masukkan harga dasar barang B: "))
harga_jual_b = int(input("Masukkan harga jual barang B: "))
harga_dasar_c = int(input("Masukkan harga dasar barang C: "))
harga_jual_c = int(input("Masukkan harga jual barang C: "))

# Menghitung keuntungan untuk setiap barang
keuntungan_a = harga_jual_a - harga_dasar_a
keuntungan_b = harga_jual_b - harga_dasar_b
keuntungan_c = harga_jual_c - harga_dasar_c

# Menentukan barang dengan keuntungan terbesar
if keuntungan_a > keuntungan_b and keuntungan_a > keuntungan_c:
  barang_terbaik = "A"
elif keuntungan_b > keuntungan_a and keuntungan_b > keuntungan_c:
  barang_terbaik = "B"
else:
  barang_terbaik = "C"

# Menampilkan barang yang harus ditawarkan
print(f"Barang yang harus ditawarkan adalah barang {barang_terbaik}")