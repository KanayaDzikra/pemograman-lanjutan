def kelas_mahasiswa(nrp_akhir):
    nrp_akhir = int(nrp_akhir)

    # menentukan kelas berdasarkan rentang NRP
    if nrp_akhir > 300:
        kelas = "K7" if nrp_akhir % 2 != 0 else "K8"
    elif nrp_akhir > 200:
        kelas = "K5" if nrp_akhir % 2 != 0 else "K6"
    elif nrp_akhir > 100:
        kelas = "K3" if nrp_akhir % 2 != 0 else "K4"
    elif nrp_akhir > 0:
        kelas = "K1" if nrp_akhir % 2 != 0 else "K2"
    else:
        kelas = "NRP Tidak Valid"

    return kelas

# input 3 digit terakhir NRP mahasiswa
nrp = input("Masukkan 3 digit terakhir NRP: ")
kelas = kelas_mahasiswa(nrp)

# menampilkan hasil
print(f"Mahasiswa dengan NRP {nrp} berada di kelas {kelas}.")